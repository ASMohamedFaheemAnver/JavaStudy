package com.construction;

public class ProjectRecord {
    public String id;
    public String title;
    public String clientId;
    public int duration;
    public int rate;
    public int numberOfAllocatedResources;
    public String type;
}
