package com.construction.operation;

public interface BillCalculater{
    int calculate();
}