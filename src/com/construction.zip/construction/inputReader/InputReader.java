package com.construction.inputReader;

public interface InputReader{
    String get();
}